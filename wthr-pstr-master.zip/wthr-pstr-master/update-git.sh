cd /root/wthr-pstr
git reset --hard origin/master
git pull
chmod +x /root/wthr-pstr/gpiomux.sh
chmod +x /root/wthr-pstr/update-git.sh
chmod +x /root/wthr-pstr/nothing.sh
