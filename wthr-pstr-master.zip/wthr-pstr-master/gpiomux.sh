omega2-ctrl gpiomux set spi_cs1 gpio
omega2-ctrl gpiomux set uart0 gpio
omega2-ctrl gpiomux set uart1 gpio
omega2-ctrl gpiomux set uart2 gpio
omega2-ctrl gpiomux set i2c gpio
omega2-ctrl gpiomux set i2s gpio
omega2-ctrl gpiomux set spi_s gpio

fast-gpio set-output 2
fast-gpio set-output 17
fast-gpio set-output 16

fast-gpio set-output 15
fast-gpio set-output 46
fast-gpio set-output 13

fast-gpio set-output 19
fast-gpio set-output 4
fast-gpio set-output 5

fast-gpio set-output 18
fast-gpio set-output 3
fast-gpio set-output 0

fast-gpio set-output 38

fast-gpio set 2 0
fast-gpio set 17 0
fast-gpio set 16 0
fast-gpio set 15 0
fast-gpio set 46 0
fast-gpio set 13 0
fast-gpio set 19 0
fast-gpio set 4 0
fast-gpio set 5 0
fast-gpio set 18 0
fast-gpio set 3 0
fast-gpio set 0 0
fast-gpio set 38 0
fast-gpio set 18 0
